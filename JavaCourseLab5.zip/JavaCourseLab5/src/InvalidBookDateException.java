/**
 * Class for invalid book date exception. It extend Exception class.
 * 
 * @author Hunkar Lule
 *
 */
public class InvalidBookDateException extends Exception {

	/** Construct an exception */
	public InvalidBookDateException(String message) {
		super(message);

	}

}
