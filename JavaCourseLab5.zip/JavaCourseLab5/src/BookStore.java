import java.util.ArrayList;
import java.util.Collections;

/**
 * Class of BookStore objects. It has a field( arraylist of Book objects).It has
 * methods to add book to bookstore and display the books in the bookstore.
 * overrides equals() method.
 * 
 * @author Hunkar Lule
 *
 */
public class BookStore {
	private ArrayList<Book> books;

	public static void main(String[] args) {

		BookStore bookStore = new BookStore();

		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_1", 2018);
		bookStore.addBook(new Name(""), new Name("lule"), "my story_2", 2014);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_3", 2015);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_4", 2012);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_5", 2017);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_6", 2011);

		bookStore.displayBooks();
	}

	/**
	 * Constructor. It initialize attribute of BookStore object.
	 */
	public BookStore() {
		books = new ArrayList<Book>();
	}

	/**
	 * Method to add book to BookStore with the specified values. It takes paramters
	 * and creates a book with that parameters. Then add that to book store.
	 * 
	 * @param firstNameook
	 * @param lastName
	 * @param title
	 * @param yearPublished
	 */
	public void addBook(Name firstName, Name lastName, String title, int yearPublished) {

		try {
			Book newBook = new Book(firstName, lastName, title, yearPublished);
			books.add(newBook);
		} catch (InvalidBookDateException e) {
			System.out.println(e.getMessage());
			System.out.println("Try again. (" + "Incorrect input: publich year can not be greater than 2017!)\n");
			// System.out.println(e.toString());
			// e.printStackTrace();
		} catch (InvalidArgumentException e) {
			System.out.println(e.getMessage());
			System.out.println("Try again. ("
					+ "Incorrect input: author first name, last name and book title  can not be null or empty!)\n");
			// System.out.println(e.toString());
			// e.printStackTrace();
		}
	}

	/**
	 * Method to list the book in the book store. t display books before sorting and
	 * after sorting.
	 */
	public void displayBooks() {
		System.out.println("======= Before sorting ========");
		for (Book book : this.getBooks()) {
			System.out.println(book);
		}
		Collections.sort(books);
		System.out.println("======== After sorting ========");
		for (Book book : this.getBooks()) {
			System.out.println(book);
		}
	}

	/**
	 * @return the books
	 */
	public final ArrayList<Book> getBooks() {
		return books;
	}

	/**
	 * @param books
	 *            the books to set
	 */
	public final void setBooks(ArrayList<Book> books) {
		this.books = books;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BookStore [books=" + books + "]";
	}

}
