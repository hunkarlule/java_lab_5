/**
 * Class of Biography objects. It extends Book class. The class has a field. The
 * class overrides equals() method.
 * 
 * @author Hunkar Lule
 * 
 */
public final class Biography extends Book {
	private Name subject;

	/**
	 * Construct a Biography objects. It calls constructor of parnet class Book.
	 * 
	 * @param subject
	 * @param authorFirstName
	 * @param authorLastName
	 * @param title
	 * @param yearPublished
	 * @throws InvalidArgumentException
	 * @throws InvalidBookDateException
	 */
	public Biography(Name subject, Name authorFirstName, Name authorLastName, String title, int yearPublished)
			throws InvalidArgumentException, InvalidBookDateException {
		super(authorFirstName, authorLastName, title, yearPublished);
		setSubject(subject);
	}

	/**
	 * @return the subject
	 */
	public final Name getSubject() {
		return subject;
	}

	/**
	 * @param subject
	 *            the subject to set
	 */
	public final void setSubject(Name subject) {
		this.subject = subject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Biography [subject=" + subject + ", getAuthorFirstName()=" + getAuthorFirstName()
				+ ", getAuthorLastName()=" + getAuthorLastName() + ", getTitle()=" + getTitle()
				+ ", getYearPublished()=" + getYearPublished() + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Biography other = (Biography) obj;
		if (subject == null) {
			if (other.subject != null) {
				return false;
			}
		} else if (!subject.equals(other.subject)) {
			return false;
		}
		return true;
	}

}
