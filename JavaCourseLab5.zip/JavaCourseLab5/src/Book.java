/**
 * Class of Book objects. It implements Comparable interface to compare book
 * objects according to year of publish. The class has 4 fields. The class also
 * overrides equals() method.
 * 
 * @author Hunkar Lule
 * 
 */
public class Book implements Comparable<Book> {
	private Name authorFirstName;
	private Name authorLastName;
	private String title;
	private int yearPublished;

	/**
	 * Construct Book objects with specified values.
	 * 
	 * @param authorFirstName
	 * @param authorLastName
	 * @param title
	 * @param yearPublished
	 */
	public Book(Name authorFirstName, Name authorLastName, String title, int yearPublished)
			throws InvalidArgumentException, InvalidBookDateException {
		setAuthorFirstName(authorFirstName);
		setAuthorLastName(authorLastName);
		setTitle(title);
		setYearPublished(yearPublished);
	}

	/**
	 * @return the authorFirstName
	 */
	public final Name getAuthorFirstName() {
		return authorFirstName;
	}

	/**
	 * Method to set firstName attribute of a Book object. It throws
	 * InvalidArgumentException if not a valid argument(authorFirstName) is passed
	 * to method.
	 * 
	 * @param authorFirstName
	 * @throws InvalidArgumentException
	 */
	public final void setAuthorFirstName(Name authorFirstName) throws InvalidArgumentException {
		if (authorFirstName == null) {
			throw new InvalidArgumentException("Invalid argument for author first name");
		}

		if (authorFirstName.getName() != null && !(authorFirstName.getName().equals(""))) {
			this.authorFirstName = authorFirstName;
		} else {
			throw new InvalidArgumentException("Invalid argument for author first name:" + authorFirstName.getName());
		}
	}

	/**
	 * @return the authorLastName
	 */
	public final Name getAuthorLastName() {
		return authorLastName;
	}

	/**
	 * Method to set latstName attribute of a Book object. It throws
	 * InvalidArgumentException if not a valid argument(authorLastName) is passed to
	 * method.
	 * 
	 * @param authorLastName
	 * @throws InvalidArgumentException
	 */
	public final void setAuthorLastName(Name authorLastName) throws InvalidArgumentException {
		if (authorFirstName == null) {
			throw new InvalidArgumentException("Invalid argument for author last name");
		}
		if (authorLastName.getName() != null && !(authorLastName.getName().equals(""))) {
			this.authorLastName = authorLastName;
		} else {
			throw new InvalidArgumentException("Invalid argument for author last name: " + authorLastName.getName());
		}
	}

	/**
	 * @return the title
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * Method to set title attribute of a Book object. It throws
	 * InvalidArgumentException if not a valid argument(title) is passed to method.
	 * 
	 * @param title
	 * @throws InvalidArgumentException
	 */
	public final void setTitle(String title) throws InvalidArgumentException {
		if (title != null && !title.equals("")) {
			this.title = title;
		} else {
			throw new InvalidArgumentException("Invalid argument for book title: " + title);
		}
	}

	/**
	 * @return the yearPublished
	 */
	public final int getYearPublished() {
		return yearPublished;
	}

	/**
	 * Method to set yearPublished attribute of a Book object. It throws
	 * InvalidBookDateException if not a valid argument(yearPublished) is passed to
	 * method.
	 * 
	 * @param yearPublished
	 * @throws InvalidBookDateException
	 */
	public final void setYearPublished(int yearPublished) throws InvalidBookDateException {
		if (yearPublished <= 2017) {
			this.yearPublished = yearPublished;
		} else {
			throw new InvalidBookDateException("The year is valid " + yearPublished);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Book [authorFirstName=" + authorFirstName + ", authorLastName=" + authorLastName + ", title=" + title
				+ ", yearPublished=" + yearPublished + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((authorFirstName == null) ? 0 : authorFirstName.hashCode());
		result = prime * result + ((authorLastName == null) ? 0 : authorLastName.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + yearPublished;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Book other = (Book) obj;
		if (title == null) {
			if (other.title != null) {
				return false;
			}
		} else if (!title.equals(other.title)) {
			return false;
		}
		if (yearPublished != other.yearPublished) {
			return false;
		}
		return true;
	}

	/**
	 * Compares 2 Book objects according to their publish year.
	 */
	public int compareTo(Book book) {
		return this.getYearPublished() - book.getYearPublished();
	}
}
