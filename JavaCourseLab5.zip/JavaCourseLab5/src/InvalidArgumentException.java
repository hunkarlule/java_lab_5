/**
 * Class for invalid argument exception. It extend Exception class.
 * 
 * @author Hunkar Lule
 *
 */
public class InvalidArgumentException extends Exception {
	// private final String input;

	public InvalidArgumentException(String message) {
		super(message);
		// this.input = input;
	}
}
