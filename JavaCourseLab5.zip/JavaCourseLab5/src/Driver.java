public class Driver {
	public static void main(String[] args) {

		BookStore bookStore = new BookStore();

		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_1", 2018); // this will not add because 2018 >
																						// 2017
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_2", 2009);
		bookStore.addBook(new Name("hunkar"), new Name(""), "my story_3", 2015); // this will not add because last name
																					// is empty string
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_4", 2012);
		bookStore.addBook(null, new Name("lule"), "my story_5", 2017); // this will not add because firtsname is null
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_6", 2015);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_7", 2014);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_8", 2007);
		bookStore.addBook(new Name("hunkar"), new Name("lule"), "my story_9", 2003);

		bookStore.displayBooks();

	}
}
